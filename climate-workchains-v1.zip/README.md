# climateProfile + workChains V1

此补丁新增：

- `climateProfile`：月令、五行数量、寒暖燥湿与通关候选的结构化特征。
- `workChains`：可计算的生、克、同类、合冲刑害破与体用路径候选。

本阶段只生成候选结构：

- 不直接定喜用神；
- 不直接判断格局高低；
- 不直接判断财富、职业和婚姻结果；
- 不把每一条生克关系都视为已经完成的“做功”。

## 使用

在项目根目录执行：

```bash
unzip -o climate-workchains-v1.zip -d /tmp/climate-workchains-v1
node /tmp/climate-workchains-v1/apply.mjs
```

然后执行：

```bash
node --check js/core/natal/config/climateAndWorkConfig.js
node --check js/core/natal/featureBuilders/buildClimateProfile.js
node --check js/core/natal/featureBuilders/buildWorkChains.js
node --check js/core/natal/natalFeatureVector.js
node --check js/core/natal/natalFeatureContract.js
npm test
```

脚本会在项目根目录建立带时间戳的备份目录。
