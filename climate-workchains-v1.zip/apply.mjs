import {
  cpSync,
  existsSync,
  mkdirSync,
  readFileSync,
  writeFileSync,
} from "node:fs";
import { dirname, join, relative, resolve } from "node:path";
import { fileURLToPath } from "node:url";

const projectRoot = process.cwd();
const scriptRoot = dirname(fileURLToPath(import.meta.url));
const payloadRoot = join(scriptRoot, "payload");

for (const path of [
  "package.json",
  "js/core/natal/natalFeatureVector.js",
  "js/core/natal/natalFeatureContract.js",
  "tests/natalFeatureIntegration.test.js",
]) {
  if (!existsSync(resolve(projectRoot, path))) {
    throw new Error(`请在项目根目录运行，缺少：${path}`);
  }
}

const stamp = new Date().toISOString().replace(/[:.]/g, "-");
const backupRoot = resolve(projectRoot, `.backup-climate-workchains-${stamp}`);

function backup(path) {
  const source = resolve(projectRoot, path);
  if (!existsSync(source)) return;
  const target = resolve(backupRoot, path);
  mkdirSync(dirname(target), { recursive: true });
  cpSync(source, target, { recursive: true });
}

function copyPayload(path) {
  const source = resolve(payloadRoot, path);
  const target = resolve(projectRoot, path);
  if (!existsSync(source)) throw new Error(`补丁包缺少 payload/${path}`);
  backup(path);
  mkdirSync(dirname(target), { recursive: true });
  cpSync(source, target, { recursive: true });
}

function writePatched(path, content) {
  backup(path);
  writeFileSync(resolve(projectRoot, path), content, "utf8");
}

function patchFeatureVector() {
  const path = "js/core/natal/natalFeatureVector.js";
  let source = readFileSync(resolve(projectRoot, path), "utf8");

  if (!source.includes('buildClimateProfile')) {
    const anchor = 'import { buildGrowthStageFeatures } from "./featureBuilders/buildGrowthStageFeatures.js";\n';
    if (!source.includes(anchor)) throw new Error("natalFeatureVector.js 导入区与预期不一致");
    source = source.replace(
      anchor,
      `${anchor}import { buildClimateProfile } from "./featureBuilders/buildClimateProfile.js";\nimport { buildWorkChains } from "./featureBuilders/buildWorkChains.js";\n`,
    );
  }

  if (!source.includes("const climateProfile = buildClimateProfile")) {
    const anchor = `  const growthStageFeatures = buildGrowthStageFeatures({
    dayMaster,
    pillars,
  });
`;
    if (!source.includes(anchor)) throw new Error("natalFeatureVector.js 构建区与预期不一致");
    source = source.replace(
      anchor,
      `${anchor}
  const climateProfile = buildClimateProfile({
    pillars,
    elements,
    structure,
  });

  const workChains = buildWorkChains({
    dayMaster,
    pillars,
    relationMatrix,
    climateProfile,
  });
`,
    );
  }

  if (!source.includes("    climateProfile,")) {
    const anchor = `    growthStageFeatures,
`;
    if (!source.includes(anchor)) throw new Error("natalFeatureVector.js 返回区与预期不一致");
    source = source.replace(anchor, `${anchor}    climateProfile,\n    workChains,\n`);
  }

  writePatched(path, source);
}

function getFunctionRange(source, functionName) {
  const start = source.indexOf(`function ${functionName}(`);
  if (start < 0) throw new Error(`未找到 ${functionName}()`);
  const bodyStart = source.indexOf("{", start);
  let depth = 0;
  for (let index = bodyStart; index < source.length; index += 1) {
    if (source[index] === "{") depth += 1;
    if (source[index] === "}") depth -= 1;
    if (depth === 0) return { start, end: index + 1 };
  }
  throw new Error(`${functionName}() 花括号不完整`);
}

function patchContract() {
  const path = "js/core/natal/natalFeatureContract.js";
  let source = readFileSync(resolve(projectRoot, path), "utf8");

  if (!source.includes("climateProfile: emptyClimateProfile()")) {
    const anchor = "    growthStageFeatures: emptyGrowthStageFeatures(),\n";
    if (!source.includes(anchor)) throw new Error("natalFeatureContract.js 顶层空结构插入点不存在");
    source = source.replace(
      anchor,
      `${anchor}    climateProfile: emptyClimateProfile(),\n    workChains: emptyWorkChains(),\n`,
    );
  }

  if (!source.includes('"climateProfile"')) {
    const anchor = `        "growthStageFeatures",
`;
    if (!source.includes(anchor)) throw new Error("natalFeatureContract.js 校验插入点不存在");
    source = source.replace(anchor, `${anchor}        "climateProfile",\n        "workChains",\n`);
  }

  if (!source.includes("function emptyClimateProfile()")) {
    const anchor = "\nfunction emptySpecialPillarMap(factory) {";
    if (!source.includes(anchor)) throw new Error("natalFeatureContract.js 函数插入点不存在");
    const helpers = `
function emptyClimateProfile() {
  return {
    version: "climate-profile-v1",
    monthBranch: "",
    season: "unknown",
    seasonLabel: "",
    baseClimate: { cold: 0, warm: 0, dry: 0, wet: 0 },
    scores: { cold: 0, warm: 0, dry: 0, wet: 0 },
    tendencies: { temperature: "unknown", moisture: "unknown" },
    severity: { temperature: "unknown", moisture: "unknown" },
    elementAvailability: {},
    priorityNeeds: [],
    candidateElements: [],
    existingSupport: [],
    missingSupport: [],
    passThroughCandidates: [],
    legacyHint: {},
    confidence: "unknown",
    evidence: [],
    warnings: [],
  };
}

function emptyWorkChains() {
  return {
    version: "work-chains-v1",
    nodes: [],
    edges: [],
    chains: [],
    bodyToUseCandidates: [],
    useToBodyCandidates: [],
    selfInvolvedCandidates: [],
    interruptionSignals: [],
    passThroughCandidates: [],
    summary: {
      nodeCount: 0,
      edgeCount: 0,
      chainCount: 0,
      bodyNodeCount: 0,
      useNodeCount: 0,
      bodyToUseCount: 0,
      interruptionCount: 0,
    },
    confidence: "unknown",
    evidence: [],
    warnings: [],
  };
}
`;
    source = source.replace(anchor, `${helpers}${anchor}`);
  }

  writePatched(path, source);
}

function patchIntegrationTest() {
  const path = "tests/natalFeatureIntegration.test.js";
  let source = readFileSync(resolve(projectRoot, path), "utf8");
  if (source.includes("featureVector.climateProfile")) return;

  const anchor = "  assert.equal(featureVector.growthStageFeatures.referenceStem, featureVector.dayMaster.stem);\n";
  if (!source.includes(anchor)) throw new Error("natalFeatureIntegration.test.js 插入点不存在");
  const additions = `  assert.ok(featureVector.climateProfile);
  assert.ok(featureVector.workChains);
  assert.equal(typeof featureVector.climateProfile.scores, "object");
  assert.ok(Array.isArray(featureVector.climateProfile.priorityNeeds));
  assert.ok(Array.isArray(featureVector.workChains.nodes));
  assert.ok(Array.isArray(featureVector.workChains.edges));
  assert.ok(Array.isArray(featureVector.workChains.chains));
  assert.equal(typeof featureVector.workChains.summary, "object");
`;
  source = source.replace(anchor, `${anchor}${additions}`);
  writePatched(path, source);
}

for (const path of [
  "js/core/natal/config/climateAndWorkConfig.js",
  "js/core/natal/featureBuilders/buildClimateProfile.js",
  "js/core/natal/featureBuilders/buildWorkChains.js",
  "tests/climateProfile.test.js",
  "tests/workChains.test.js",
]) {
  copyPayload(path);
}

patchFeatureVector();
patchContract();
patchIntegrationTest();

console.log("climateProfile + workChains V1 补丁已应用。");
console.log(`备份目录：${relative(projectRoot, backupRoot)}`);
console.log("");
console.log("请运行：");
console.log("node --check js/core/natal/config/climateAndWorkConfig.js");
console.log("node --check js/core/natal/featureBuilders/buildClimateProfile.js");
console.log("node --check js/core/natal/featureBuilders/buildWorkChains.js");
console.log("node --check js/core/natal/natalFeatureVector.js");
console.log("node --check js/core/natal/natalFeatureContract.js");
console.log("npm test");
