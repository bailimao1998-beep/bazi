# 特殊状态特征收口补丁

此补丁完成：

1. 旬空、十二长生、墓库配置统一到：
   `js/core/bazi/specialStateTables.js`
2. `js/core/natal/config/specialStateTables.js`
   改为兼容性重导出。
3. `calculateBazi.js` 删除重复的旬空表和十二长生表。
4. 三个特殊状态特征的空合同稳定包含：
   `year/month/day/hour`。
5. 增加共享数据源测试。

## 使用

在项目根目录执行：

```bash
unzip -o special-state-unification-v1.zip -d /tmp/special-state-unification-v1
node /tmp/special-state-unification-v1/apply.mjs
```

然后执行：

```bash
node --check js/core/bazi/specialStateTables.js
node --check js/core/bazi/calculateBazi.js
node --check js/core/natal/natalFeatureContract.js
npm test
```

脚本执行前会在项目根目录创建带时间戳的备份目录。
