import {
  cpSync,
  existsSync,
  mkdirSync,
  readFileSync,
  writeFileSync,
} from "node:fs";
import { dirname, join, relative, resolve } from "node:path";
import { fileURLToPath } from "node:url";

const projectRoot = process.cwd();
const scriptRoot = dirname(fileURLToPath(import.meta.url));
const payloadRoot = join(scriptRoot, "payload");

const requiredPaths = [
  "package.json",
  "js/core/bazi/calculateBazi.js",
  "js/core/natal/natalFeatureContract.js",
  "js/core/natal/config/specialStateTables.js",
  "tests/natalFeatureContract.test.js",
];

for (const path of requiredPaths) {
  if (!existsSync(resolve(projectRoot, path))) {
    throw new Error(`请在项目根目录运行，缺少：${path}`);
  }
}

const stamp = new Date().toISOString().replace(/[:.]/g, "-");
const backupRoot = resolve(
  projectRoot,
  `.backup-special-state-unification-${stamp}`,
);

function backup(path) {
  const source = resolve(projectRoot, path);
  if (!existsSync(source)) return;

  const target = resolve(backupRoot, path);
  mkdirSync(dirname(target), { recursive: true });
  cpSync(source, target, { recursive: true });
}

function copyPayload(path) {
  const source = resolve(payloadRoot, path);
  const target = resolve(projectRoot, path);

  if (!existsSync(source)) {
    throw new Error(`补丁包缺少 payload/${path}`);
  }

  backup(path);
  mkdirSync(dirname(target), { recursive: true });
  cpSync(source, target, { recursive: true });
}

function writePatched(path, content) {
  backup(path);
  writeFileSync(resolve(projectRoot, path), content, "utf8");
}

function patchCalculateBazi() {
  const path = "js/core/bazi/calculateBazi.js";
  let source = readFileSync(resolve(projectRoot, path), "utf8");

  if (!source.includes('from "./specialStateTables.js"')) {
    const anchor = '} from "./pillarMath.js";\n';

    if (!source.includes(anchor)) {
      throw new Error("calculateBazi.js 的导入区与预期不一致");
    }

    source = source.replace(
      anchor,
      `${anchor}import {
  TWELVE_GROWTH_MATRIX,
  resolveVoidBranches,
} from "./specialStateTables.js";
`,
    );
  }

  const tableStart = source.indexOf("const voidBranchesByDecade = [");
  const calculationStart = source.indexOf("export function calculateBazi");

  if (tableStart >= 0) {
    if (
      calculationStart < tableStart ||
      !source.slice(tableStart, calculationStart).includes(
        "const twelveStageMatrix =",
      )
    ) {
      throw new Error("calculateBazi.js 的特殊状态表范围与预期不一致");
    }

    source =
      source.slice(0, tableStart) +
      source.slice(calculationStart);
  }

  source = source.replaceAll(
    "twelveStageMatrix",
    "TWELVE_GROWTH_MATRIX",
  );

  const voidFunctionPattern =
    /function getVoidBranches\(pillar\) \{[\s\S]*?\n\}/;

  if (voidFunctionPattern.test(source)) {
    source = source.replace(
      voidFunctionPattern,
      `function getVoidBranches(pillar) {
  return resolveVoidBranches(
    pillar?.stem,
    pillar?.branch,
  );
}`,
    );
  } else if (
    !source.includes(
      "return resolveVoidBranches(",
    )
  ) {
    throw new Error("未找到 calculateBazi.js 的 getVoidBranches()");
  }

  if (/const voidBranchesByDecade\s*=/.test(source)) {
    throw new Error("旬空重复表未删除");
  }

  if (/const twelveStageMatrix\s*=/.test(source)) {
    throw new Error("十二长生重复表未删除");
  }

  writePatched(path, source);
}

function getFunctionRange(source, functionName) {
  const start = source.indexOf(`function ${functionName}(`);

  if (start < 0) {
    throw new Error(`未找到 ${functionName}()`);
  }

  const bodyStart = source.indexOf("{", start);
  let depth = 0;

  for (let index = bodyStart; index < source.length; index += 1) {
    const char = source[index];

    if (char === "{") depth += 1;
    if (char === "}") depth -= 1;

    if (depth === 0) {
      return {
        start,
        end: index + 1,
      };
    }
  }

  throw new Error(`${functionName}() 花括号不完整`);
}

function patchFunction(source, functionName, transform) {
  const range = getFunctionRange(source, functionName);
  const current = source.slice(range.start, range.end);
  const next = transform(current);

  if (next === current) {
    throw new Error(`${functionName}() 未发生预期修改`);
  }

  return (
    source.slice(0, range.start) +
    next +
    source.slice(range.end)
  );
}

function patchContract() {
  const path = "js/core/natal/natalFeatureContract.js";
  let source = readFileSync(resolve(projectRoot, path), "utf8");

  if (!source.includes("function emptySpecialPillarMap(")) {
    const anchor = "\nfunction emptyVoidFeatures() {";

    if (!source.includes(anchor)) {
      throw new Error("natalFeatureContract.js 缺少插入点");
    }

    const helpers = `
function emptySpecialPillarMap(factory) {
  return Object.fromEntries(
    pillarKeys.map((key) => [key, factory(key)]),
  );
}

function emptyVoidPillarFeature(key) {
  return {
    key,
    label: "",
    branch: "",
    isVoid: false,
    referencePillar: "day",
    branchMainTenGod: "",
    hiddenTenGods: [],
    evidence: [],
    warnings: [],
  };
}

function emptyStoragePillarFeature(key) {
  return {
    key,
    label: "",
    branch: "",
    isStorage: false,
    storageElement: "",
    storageElementLabel: "",
    storageLabel: "",
    storedStem: "",
    storedTenGod: "",
    hiddenStems: [],
    hiddenTenGods: [],
    relationIds: [],
    relationTypes: [],
    openingSignalRelationIds: [],
    openingSignalTypes: [],
    hasOpeningSignal: false,
    openState: "unknown",
    evidence: [],
    warnings: [],
  };
}

function emptyGrowthStagePillarFeature(key) {
  return {
    key,
    label: "",
    branch: "",
    stage: "unknown",
    stageIndex: -1,
    phase: "unknown",
    isKnown: false,
    evidence: [],
    warnings: [],
  };
}
`;

    source = source.replace(
      anchor,
      `${helpers}${anchor}`,
    );
  }

  source = patchFunction(
    source,
    "emptyVoidFeatures",
    (block) => block.replace(
      "byPillar: {},",
      "byPillar: emptySpecialPillarMap(emptyVoidPillarFeature),",
    ),
  );

  source = patchFunction(
    source,
    "emptyStorageFeatures",
    (block) => block.replace(
      "byPillar: {},",
      "byPillar: emptySpecialPillarMap(emptyStoragePillarFeature),",
    ),
  );

  source = patchFunction(
    source,
    "emptyGrowthStageFeatures",
    (block) => block.replace(
      "byPillar: {},",
      "byPillar: emptySpecialPillarMap(emptyGrowthStagePillarFeature),",
    ),
  );

  writePatched(path, source);
}

function patchContractTest() {
  const path = "tests/natalFeatureContract.test.js";
  let source = readFileSync(resolve(projectRoot, path), "utf8");

  if (
    source.includes(
      "Object.keys(vector.voidFeatures.byPillar)",
    )
  ) {
    return;
  }

  const anchor =
    "  assert.deepEqual(vector.kinshipFeatures.spouse.candidateStarProfiles, []);\n";

  if (!source.includes(anchor)) {
    throw new Error("natalFeatureContract.test.js 插入点与预期不一致");
  }

  const additions = `  assert.deepEqual(
    Object.keys(vector.voidFeatures.byPillar),
    ["year", "month", "day", "hour"],
  );
  assert.deepEqual(
    Object.keys(vector.storageFeatures.byPillar),
    ["year", "month", "day", "hour"],
  );
  assert.deepEqual(
    Object.keys(vector.growthStageFeatures.byPillar),
    ["year", "month", "day", "hour"],
  );
`;

  source = source.replace(
    anchor,
    `${anchor}${additions}`,
  );

  writePatched(path, source);
}

copyPayload("js/core/bazi/specialStateTables.js");
copyPayload("js/core/natal/config/specialStateTables.js");
copyPayload("tests/specialStateTables.test.js");

patchCalculateBazi();
patchContract();
patchContractTest();

console.log("特殊状态特征收口补丁已应用。");
console.log(`备份目录：${relative(projectRoot, backupRoot)}`);
console.log("");
console.log("请运行：");
console.log("node --check js/core/bazi/specialStateTables.js");
console.log("node --check js/core/bazi/calculateBazi.js");
console.log("node --check js/core/natal/natalFeatureContract.js");
console.log("npm test");
