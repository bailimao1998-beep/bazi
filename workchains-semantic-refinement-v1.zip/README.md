# workChains 语义精度收口 V1

本补丁处理四项问题：

1. 藏干节点真正进入低置信内部路径。
2. 潜在五行边与原局关系激活边分层，并合并同一控制关系。
3. 共存通关候选与真实冲突候选分开。
4. 体用角色改为可配置，并保留：
   - `defaultRole`
   - `resolvedRole`
   - `roleEvidence`

兼容字段仍然保留：

- `node.role`
- `workChains.passThroughCandidates`
- `workChains.version`

所有路径仍然是：

```js
status: "candidate"
```

不会直接生成财富、职业、婚姻或成败结论。

## 使用

在项目根目录执行：

```bash
unzip -o workchains-semantic-refinement-v1.zip -d /tmp/workchains-semantic-refinement-v1
node /tmp/workchains-semantic-refinement-v1/apply.mjs
```

然后执行：

```bash
node --check js/core/natal/config/climateAndWorkConfig.js
node --check js/core/natal/featureBuilders/buildWorkChains.js
node --check js/core/natal/natalFeatureContract.js
npm test
```
