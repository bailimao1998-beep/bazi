import {
  cpSync,
  existsSync,
  mkdirSync,
  readFileSync,
  writeFileSync,
} from "node:fs";
import { dirname, join, relative, resolve } from "node:path";
import { fileURLToPath } from "node:url";

const projectRoot = process.cwd();
const scriptRoot = dirname(fileURLToPath(import.meta.url));
const payloadRoot = join(scriptRoot, "payload");

for (const path of [
  "package.json",
  "js/core/natal/config/climateAndWorkConfig.js",
  "js/core/natal/featureBuilders/buildWorkChains.js",
  "js/core/natal/natalFeatureContract.js",
  "tests/workChains.test.js",
  "tests/natalFeatureIntegration.test.js",
]) {
  if (!existsSync(resolve(projectRoot, path))) {
    throw new Error(`请在项目根目录运行，缺少：${path}`);
  }
}

const stamp = new Date().toISOString().replace(/[:.]/g, "-");
const backupRoot = resolve(
  projectRoot,
  `.backup-workchains-semantic-${stamp}`,
);

function backup(path) {
  const source = resolve(projectRoot, path);
  if (!existsSync(source)) return;

  const target = resolve(backupRoot, path);
  mkdirSync(dirname(target), { recursive: true });
  cpSync(source, target, { recursive: true });
}

function copyPayload(path) {
  const source = resolve(payloadRoot, path);
  const target = resolve(projectRoot, path);

  if (!existsSync(source)) {
    throw new Error(`补丁包缺少 payload/${path}`);
  }

  backup(path);
  mkdirSync(dirname(target), { recursive: true });
  cpSync(source, target, { recursive: true });
}

function writePatched(path, content) {
  backup(path);
  writeFileSync(resolve(projectRoot, path), content, "utf8");
}

function getFunctionRange(source, functionName) {
  const start = source.indexOf(`function ${functionName}(`);
  if (start < 0) throw new Error(`未找到 ${functionName}()`);

  const bodyStart = source.indexOf("{", start);
  let depth = 0;

  for (let index = bodyStart; index < source.length; index += 1) {
    if (source[index] === "{") depth += 1;
    if (source[index] === "}") depth -= 1;

    if (depth === 0) {
      return {
        start,
        end: index + 1,
      };
    }
  }

  throw new Error(`${functionName}() 花括号不完整`);
}

function replaceFunction(source, functionName, nextFunction) {
  const range = getFunctionRange(source, functionName);

  return (
    source.slice(0, range.start) +
    nextFunction +
    source.slice(range.end)
  );
}

function patchContract() {
  const path = "js/core/natal/natalFeatureContract.js";
  let source = readFileSync(resolve(projectRoot, path), "utf8");

  const nextEmptyWorkChains = `function emptyWorkChains() {
  return {
    version: "work-chains-v1",
    semanticVersion: "work-chains-semantic-v1",
    roleMappingVersion: "",
    roleMappingId: "",
    nodes: [],
    edges: [],
    potentialEdges: [],
    activatedEdges: [],
    chains: [],
    bodyToUseCandidates: [],
    useToBodyCandidates: [],
    selfInvolvedCandidates: [],
    interruptionSignals: [],
    coexistenceCandidates: [],
    actualConflictCandidates: [],
    passThroughCandidates: [],
    summary: {
      nodeCount: 0,
      edgeCount: 0,
      potentialEdgeCount: 0,
      activatedEdgeCount: 0,
      chainCount: 0,
      activatedChainCount: 0,
      bodyNodeCount: 0,
      mediatorNodeCount: 0,
      useNodeCount: 0,
      hiddenNodeCount: 0,
      bodyToUseCount: 0,
      interruptionCount: 0,
      actualConflictCount: 0,
    },
    confidence: "unknown",
    evidence: [],
    warnings: [],
  };
}`;

  source = replaceFunction(
    source,
    "emptyWorkChains",
    nextEmptyWorkChains,
  );

  const oldValidation = `      for (const key of ["nodes", "edges", "chains"]) {
        if (!Array.isArray(vector.workChains[key])) {
          errors.push(\`workChains.\${key} should be an array\`);
        }
      }
      if (!isPlainObject(vector.workChains.summary)) {
        errors.push("workChains.summary should be an object");
      }`;

  const newValidation = `      for (const key of [
        "nodes",
        "edges",
        "potentialEdges",
        "activatedEdges",
        "chains",
        "coexistenceCandidates",
        "actualConflictCandidates",
      ]) {
        if (!Array.isArray(vector.workChains[key])) {
          errors.push(\`workChains.\${key} should be an array\`);
        }
      }
      if (!isPlainObject(vector.workChains.summary)) {
        errors.push("workChains.summary should be an object");
      }`;

  if (!source.includes(oldValidation)) {
    throw new Error(
      "natalFeatureContract.js 的workChains校验区与预期不一致",
    );
  }

  source = source.replace(
    oldValidation,
    newValidation,
  );

  writePatched(path, source);
}

function patchIntegrationTest() {
  const path = "tests/natalFeatureIntegration.test.js";
  let source = readFileSync(resolve(projectRoot, path), "utf8");

  if (
    source.includes(
      "featureVector.workChains.actualConflictCandidates",
    )
  ) {
    return;
  }

  const anchor =
    '  assert.equal(typeof featureVector.workChains.summary, "object");\n';

  if (!source.includes(anchor)) {
    throw new Error(
      "natalFeatureIntegration.test.js 插入点与预期不一致",
    );
  }

  const additions = `  assert.ok(Array.isArray(featureVector.workChains.potentialEdges));
  assert.ok(Array.isArray(featureVector.workChains.activatedEdges));
  assert.ok(Array.isArray(featureVector.workChains.coexistenceCandidates));
  assert.ok(Array.isArray(featureVector.workChains.actualConflictCandidates));
  assert.ok(featureVector.workChains.nodes.every((node) =>
    typeof node.defaultRole === "string" &&
    typeof node.resolvedRole === "string" &&
    Array.isArray(node.roleEvidence)
  ));
  assert.ok(featureVector.workChains.edges.every((edge) =>
    ["potential", "activated"].includes(edge.activation)
  ));
`;

  source = source.replace(
    anchor,
    `${anchor}${additions}`,
  );

  writePatched(path, source);
}

copyPayload("js/core/natal/config/climateAndWorkConfig.js");
copyPayload("js/core/natal/featureBuilders/buildWorkChains.js");
copyPayload("tests/workChains.test.js");

patchContract();
patchIntegrationTest();

console.log("workChains语义精度补丁已应用。");
console.log(`备份目录：${relative(projectRoot, backupRoot)}`);
console.log("");
console.log("请运行：");
console.log("node --check js/core/natal/config/climateAndWorkConfig.js");
console.log("node --check js/core/natal/featureBuilders/buildWorkChains.js");
console.log("node --check js/core/natal/natalFeatureContract.js");
console.log("npm test");
